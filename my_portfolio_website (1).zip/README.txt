# Personal Portfolio Website

## Files
- `index.html` — website content and sections
- `style.css` — colors, layout, and responsive design
- `script.js` — mobile navigation and current year

## Run it
1. Extract the ZIP file.
2. Open the folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the Live Server extension.

## Customize before publishing
- Replace `Your Name` in `index.html` with your name.
- Replace `your.email@example.com` with your email address.
- Update the project cards with projects you have actually completed.
- Add your GitHub and LinkedIn links when ready.

The website uses HTML, CSS, and JavaScript. Your listed skills (HTML, CSS, JavaScript, Python) are included.
